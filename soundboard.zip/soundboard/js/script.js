//ONE//
soundManager.setup({
 url: '/path/to/swf-files/',
 onready: function() {

   $("#nine").on("click", function(){
 var mySound = soundManager.createSound({
 url: 'audiofiles/ok.mp3'
 });
 mySound.play();

})
 },
 ontimeout: function() {
 }
});
// TWO //
soundManager.setup({
 url: '/path/to/swf-files/',
 onready: function() {

   $("#one").on("click", function(){
 var mySound = soundManager.createSound({
 url: 'audiofiles/ok.mp3'
 });
 mySound.play();

})
 },
 ontimeout: function() {
 }
});
// TWO //
soundManager.setup({
 url: '/path/to/swf-files/',
 onready: function() {

   $("#two").on("click", function(){
 var mySound = soundManager.createSound({
 url: 'audiofiles/ok.mp3'
 });
 mySound.play();

})
 },
 ontimeout: function() {
 }
});
//THREE//
soundManager.setup({
 url: '/path/to/swf-files/',
 onready: function() {

   $("#three").on("click", function(){
 var mySound = soundManager.createSound({
 url: 'audiofiles/ok.mp3'
 });
 mySound.play();

})
 },
 ontimeout: function() {
 }
});
//FOUR//
soundManager.setup({
 url: '/path/to/swf-files/',
 onready: function() {

   $("#four").on("click", function(){
 var mySound = soundManager.createSound({
 url: 'audiofiles/ok.mp3'
 });
 mySound.play();

})
 },
 ontimeout: function() {
 }
});
//FIVE//
soundManager.setup({
 url: '/path/to/swf-files/',
 onready: function() {

   $("#one").on("click", function(){
 var mySound = soundManager.createSound({
 url: 'audiofiles/ok.mp3'
 });
 mySound.play();

})
 },
 ontimeout: function() {
 }
});
//SIX//
soundManager.setup({
 url: '/path/to/swf-files/',
 onready: function() {

   $("#one").on("click", function(){
 var mySound = soundManager.createSound({
 url: 'audiofiles/ok.mp3'
 });
 mySound.play();

})
 },
 ontimeout: function() {
 }
});
//SEVEN//
soundManager.setup({
 url: '/path/to/swf-files/',
 onready: function() {

   $("#one").on("click", function(){
 var mySound = soundManager.createSound({
 url: 'audiofiles/ok.mp3'
 });
 mySound.play();

})
 },
 ontimeout: function() {
 }
});

//EIGHT//
soundManager.setup({
 url: '/path/to/swf-files/',
 onready: function() {

   $("#one").on("click", function(){
 var mySound = soundManager.createSound({
 url: 'audiofiles/ok.mp3'
 });
 mySound.play();

})
 },
 ontimeout: function() {
 }
});

//NINE//
soundManager.setup({
 url: '/path/to/swf-files/',
 onready: function() {

   $("#one").on("click", function(){
 var mySound = soundManager.createSound({
 url: 'audiofiles/ok.mp3'
 });
 mySound.play();

})
 },
 ontimeout: function() {
 }
});